namespace PRELIM_LAB3_BSIT_31A3Daniel_Red.Models;

public class ErrorViewModel
{
    public string? RequestId { get; set; }

    public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
}