﻿namespace PRELIM_LAB3_BSIT_31A3Daniel_Red.Models
{
    public interface IDescribeable
    {
        string GetDescription();
    }
}